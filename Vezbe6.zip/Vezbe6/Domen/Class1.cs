﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    class Class1
    {
        public int ID { get; set; }
        public string Naziv { get; set; }

        //[Browsable(false)]       

        //[DisplayName("Proizvodjac")]\

        public override string ToString()
        {
            return Naziv;
        }
        public override bool Equals(object obj)
        {
            if (obj is Class1 p)
            {
                return p.ID == ID;
            }
            return false;
        }
        public Class1 Self { get { return this; } } 
    }

    public class Korisnik
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string KorisnickoIme { get; set; }
        public string Password { get; set; }
    }
}
