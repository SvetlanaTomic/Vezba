﻿using BrokerBazePodataka;
using Domen;
using Storage;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kontroler
{
    public class Kontroler
    {
        private Broker broker = new Broker();
        private static Kontroler _instance;
        public static Kontroler Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Kontroler();
                }
                return _instance;
            }
        }
        private Kontroler()
        {
        }

        public Korisnik Prijava(string korIme, string pass)
        {
            StorageKorisnik storageKorisnik = new StorageKorisnik();
            List<Korisnik> korisnici = storageKorisnik.VratiSve();
            foreach (Korisnik k in korisnici)
            {
                if (k.KorisnickoIme == korIme && k.Password == pass)
                {
                    return k;
                }
            }
            return null;
        }

        public object Vrati()
        {
            throw new NotImplementedException();
        }

        public bool Sacuvaj(object racun)
        {

            try
            {
                broker.OtvoriKonekciju();
                broker.PokreniTransakciju();
                //broker.Sacuvaj(racun);

                broker.Commit();
                return true;

            }
            catch (Exception)
            {

                broker.Rollback();
                return false;
            }
            finally
            {
                broker.ZatvoriKonekciju();
            }

        }
        
    }
}
