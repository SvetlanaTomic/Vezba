﻿namespace Forme
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.cmbPrimer = new System.Windows.Forms.ComboBox();
            this.dgvPrimer = new System.Windows.Forms.DataGridView();
            this.txtCena = new System.Windows.Forms.TextBox();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.txtDatum = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrimer)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(50, 140);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbPrimer
            // 
            this.cmbPrimer.FormattingEnabled = true;
            this.cmbPrimer.Location = new System.Drawing.Point(246, 63);
            this.cmbPrimer.Name = "cmbPrimer";
            this.cmbPrimer.Size = new System.Drawing.Size(121, 28);
            this.cmbPrimer.TabIndex = 1;
            // 
            // dgvPrimer
            // 
            this.dgvPrimer.AllowUserToAddRows = false;
            this.dgvPrimer.AllowUserToDeleteRows = false;
            this.dgvPrimer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrimer.Location = new System.Drawing.Point(246, 196);
            this.dgvPrimer.Name = "dgvPrimer";
            this.dgvPrimer.ReadOnly = true;
            this.dgvPrimer.RowTemplate.Height = 28;
            this.dgvPrimer.Size = new System.Drawing.Size(240, 150);
            this.dgvPrimer.TabIndex = 2;
            // 
            // txtCena
            // 
            this.txtCena.Location = new System.Drawing.Point(269, 116);
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(100, 26);
            this.txtCena.TabIndex = 3;
            // 
            // txtIme
            // 
            this.txtIme.Location = new System.Drawing.Point(385, 116);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(100, 26);
            this.txtIme.TabIndex = 4;
            // 
            // txtDatum
            // 
            this.txtDatum.Location = new System.Drawing.Point(516, 116);
            this.txtDatum.Name = "txtDatum";
            this.txtDatum.Size = new System.Drawing.Size(100, 26);
            this.txtDatum.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtDatum);
            this.Controls.Add(this.txtIme);
            this.Controls.Add(this.txtCena);
            this.Controls.Add(this.dgvPrimer);
            this.Controls.Add(this.cmbPrimer);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrimer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmbPrimer;
        private System.Windows.Forms.DataGridView dgvPrimer;
        private System.Windows.Forms.TextBox txtCena;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.TextBox txtDatum;
    }
}