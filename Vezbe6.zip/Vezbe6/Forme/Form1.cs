﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void SrediFormu()
        {
            if (Sesija.Instance.Korisnik != null)
            {
                SrediFormu2();
               // cmbProizvod.DataSource = Kontroler.Kontroler.Instance.VratiSveProizvode();
                cmbPrimer.DisplayMember = "Naziv"; 
            }
            else
            {
                MessageBox.Show("Niste prijavljeni!");
            }
        }
        private void SrediFormu2()
        {
            dgvPrimer.Columns["Dobavljac"].Visible = false;
            DataGridViewComboBoxColumn colPrimer = new DataGridViewComboBoxColumn();
            colPrimer.DataPropertyName = "Dobavljac";
            colPrimer.DataSource = Kontroler.Kontroler.Instance.Vrati();
            colPrimer.DisplayMember = "Naziv";
            colPrimer.ValueMember = "Self";
            colPrimer.HeaderText = "Izaberi dobavljaca";
            dgvPrimer.Columns.Add(colPrimer);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(Validacija())
            {

            }
            //Proizvod odabraniProizvod = (Proizvod)dgvProizvodi.SelectedRows[0].DataBoundItem;
            //Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy.", null)
            //za brisanje
            //dgvDobavljanja.SelectedRows.Count > 0
        }

        private bool Validacija()
        {
            bool pom = true;

            if (string.IsNullOrEmpty(txtIme.Text))
            {
                txtIme.BackColor = Color.LightCoral;
                pom = false;
            }
            else
            {
                txtIme.BackColor = Color.White;
            }

            if (string.IsNullOrEmpty(txtCena.Text))
            {
                txtCena.BackColor = Color.LightCoral;
                pom = false;
            }
            else
            {
                txtCena.BackColor = Color.White;
            }

            if (!double.TryParse(txtCena.Text, out double _))
            {
                txtCena.BackColor = Color.LightCoral;
                pom = false;
            }
            else
            {
                txtCena.BackColor = Color.White;
            }

            if (cmbPrimer.SelectedItem == null)
            {
                cmbPrimer.BackColor = Color.LightCoral;
                pom = false;
            }
            else
            {
                cmbPrimer.BackColor = Color.White;
            }
            if (!DateTime.TryParseExact(txtDatum.Text, "dd.MM.yyyy.", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime datum))
            {
                txtDatum.BackColor = Color.LightCoral;
                pom = false;
            }
            else
            {
                txtDatum.BackColor = Color.White;
            }
                return pom;

        }

        private void OcistiFormu()
        {
            txtDatum.Clear();
            txtCena.Text = String.Empty;
            txtIme.Text = String.Empty;
            cmbPrimer.SelectedIndex = 0;
        }
    }
}
